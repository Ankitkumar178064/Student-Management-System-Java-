# Employee Database (SQL)

A small relational database with two tables (`departments`, `employees`) and 10 practice queries.

## Topics Covered
Primary and foreign keys, INSERT, SELECT, WHERE, ORDER BY, GROUP BY, HAVING, JOINs, subqueries, UPDATE, DELETE, aggregate functions (COUNT, AVG, MAX).

## How to Run
- **MySQL:** `mysql -u root -p < employee_database.sql`
- **SQLite:** `sqlite3 company.db < employee_database.sql`
- **Online:** paste the file into any online SQL editor.

## Author
Ankit Kumar Rajak
