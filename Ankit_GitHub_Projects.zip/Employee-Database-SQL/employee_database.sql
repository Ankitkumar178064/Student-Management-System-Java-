-- Employee Database Project (MySQL / SQLite compatible)
-- Covers: CREATE, INSERT, SELECT, WHERE, ORDER BY, GROUP BY, HAVING, JOIN, UPDATE, DELETE

DROP TABLE IF EXISTS employees;
DROP TABLE IF EXISTS departments;

CREATE TABLE departments (
    dept_id   INT PRIMARY KEY,
    dept_name VARCHAR(50) NOT NULL,
    location  VARCHAR(50)
);

CREATE TABLE employees (
    emp_id    INT PRIMARY KEY,
    emp_name  VARCHAR(60) NOT NULL,
    dept_id   INT,
    salary    DECIMAL(10,2),
    join_date DATE,
    FOREIGN KEY (dept_id) REFERENCES departments(dept_id)
);

INSERT INTO departments VALUES
(1, 'IT',        'Ranchi'),
(2, 'HR',        'Jamshedpur'),
(3, 'Finance',   'Kolkata'),
(4, 'Marketing', 'Patna');

INSERT INTO employees VALUES
(101, 'Amit Sharma',   1, 55000, '2022-03-15'),
(102, 'Priya Singh',   1, 62000, '2021-07-01'),
(103, 'Rohit Verma',   2, 40000, '2023-01-10'),
(104, 'Neha Gupta',    3, 58000, '2020-11-25'),
(105, 'Suresh Kumar',  3, 47000, '2022-09-05'),
(106, 'Anjali Mehta',  4, 45000, '2023-04-18'),
(107, 'Vikas Yadav',   1, 70000, '2019-06-30'),
(108, 'Pooja Das',     2, 38000, '2024-02-12');

-- 1. View all employees
SELECT * FROM employees;

-- 2. Employees earning more than 50000
SELECT emp_name, salary FROM employees WHERE salary > 50000;

-- 3. Employees sorted by salary (highest first)
SELECT emp_name, salary FROM employees ORDER BY salary DESC;

-- 4. Employee count per department
SELECT d.dept_name, COUNT(e.emp_id) AS total_employees
FROM departments d
LEFT JOIN employees e ON d.dept_id = e.dept_id
GROUP BY d.dept_name;

-- 5. Average salary per department
SELECT d.dept_name, ROUND(AVG(e.salary), 2) AS avg_salary
FROM employees e
JOIN departments d ON e.dept_id = d.dept_id
GROUP BY d.dept_name;

-- 6. Departments whose average salary is above 50000
SELECT d.dept_name, AVG(e.salary) AS avg_salary
FROM employees e
JOIN departments d ON e.dept_id = d.dept_id
GROUP BY d.dept_name
HAVING AVG(e.salary) > 50000;

-- 7. Employee names with department and location (JOIN)
SELECT e.emp_name, d.dept_name, d.location
FROM employees e
JOIN departments d ON e.dept_id = d.dept_id;

-- 8. Highest paid employee
SELECT emp_name, salary FROM employees
WHERE salary = (SELECT MAX(salary) FROM employees);

-- 9. Give a 10% raise to the IT department
UPDATE employees SET salary = salary * 1.10 WHERE dept_id = 1;

-- 10. Delete an employee
DELETE FROM employees WHERE emp_id = 108;
