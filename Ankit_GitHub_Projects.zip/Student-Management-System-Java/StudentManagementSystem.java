import java.io.*;
import java.util.*;

/**
 * Student Management System
 * Console application using OOP, ArrayList and file handling.
 * Features: Add, View, Search, Update, Delete students (data saved to students.txt).
 */
class Student {
    private int id;
    private String name;
    private String course;
    private double marks;

    public Student(int id, String name, String course, double marks) {
        this.id = id;
        this.name = name;
        this.course = course;
        this.marks = marks;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public String getCourse() { return course; }
    public double getMarks() { return marks; }

    public void setName(String name) { this.name = name; }
    public void setCourse(String course) { this.course = course; }
    public void setMarks(double marks) { this.marks = marks; }

    public String getGrade() {
        if (marks >= 90) return "A+";
        if (marks >= 75) return "A";
        if (marks >= 60) return "B";
        if (marks >= 45) return "C";
        return "F";
    }

    public String toFileString() {
        return id + "," + name + "," + course + "," + marks;
    }

    @Override
    public String toString() {
        return String.format("%-6d %-20s %-12s %-8.2f %-5s", id, name, course, marks, getGrade());
    }
}

public class StudentManagementSystem {
    private static final String FILE_NAME = "students.txt";
    private static final ArrayList<Student> students = new ArrayList<>();
    private static final Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        loadFromFile();
        int choice;
        do {
            System.out.println("\n===== STUDENT MANAGEMENT SYSTEM =====");
            System.out.println("1. Add Student");
            System.out.println("2. View All Students");
            System.out.println("3. Search Student by ID");
            System.out.println("4. Update Student");
            System.out.println("5. Delete Student");
            System.out.println("6. Exit");
            choice = readInt("Enter your choice: ");

            switch (choice) {
                case 1: addStudent(); break;
                case 2: viewStudents(); break;
                case 3: searchStudent(); break;
                case 4: updateStudent(); break;
                case 5: deleteStudent(); break;
                case 6: saveToFile(); System.out.println("Data saved. Goodbye!"); break;
                default: System.out.println("Invalid choice. Try again.");
            }
        } while (choice != 6);
    }

    private static void addStudent() {
        int id = readInt("Enter ID: ");
        if (findById(id) != null) {
            System.out.println("A student with this ID already exists.");
            return;
        }
        System.out.print("Enter name: ");
        String name = sc.nextLine().trim();
        System.out.print("Enter course: ");
        String course = sc.nextLine().trim();
        double marks = readDouble("Enter marks (0-100): ");
        students.add(new Student(id, name, course, marks));
        saveToFile();
        System.out.println("Student added successfully.");
    }

    private static void viewStudents() {
        if (students.isEmpty()) {
            System.out.println("No records found.");
            return;
        }
        System.out.println(String.format("%-6s %-20s %-12s %-8s %-5s", "ID", "Name", "Course", "Marks", "Grade"));
        System.out.println("-----------------------------------------------------------");
        for (Student s : students) System.out.println(s);
    }

    private static void searchStudent() {
        int id = readInt("Enter ID to search: ");
        Student s = findById(id);
        if (s == null) System.out.println("Student not found.");
        else {
            System.out.println(String.format("%-6s %-20s %-12s %-8s %-5s", "ID", "Name", "Course", "Marks", "Grade"));
            System.out.println(s);
        }
    }

    private static void updateStudent() {
        int id = readInt("Enter ID to update: ");
        Student s = findById(id);
        if (s == null) {
            System.out.println("Student not found.");
            return;
        }
        System.out.print("New name (" + s.getName() + "): ");
        String name = sc.nextLine().trim();
        System.out.print("New course (" + s.getCourse() + "): ");
        String course = sc.nextLine().trim();
        double marks = readDouble("New marks (" + s.getMarks() + "): ");
        if (!name.isEmpty()) s.setName(name);
        if (!course.isEmpty()) s.setCourse(course);
        s.setMarks(marks);
        saveToFile();
        System.out.println("Student updated successfully.");
    }

    private static void deleteStudent() {
        int id = readInt("Enter ID to delete: ");
        Student s = findById(id);
        if (s == null) {
            System.out.println("Student not found.");
            return;
        }
        students.remove(s);
        saveToFile();
        System.out.println("Student deleted successfully.");
    }

    private static Student findById(int id) {
        for (Student s : students) if (s.getId() == id) return s;
        return null;
    }

    private static int readInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            try {
                return Integer.parseInt(sc.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid whole number.");
            }
        }
    }

    private static double readDouble(String prompt) {
        while (true) {
            System.out.print(prompt);
            try {
                double d = Double.parseDouble(sc.nextLine().trim());
                if (d >= 0 && d <= 100) return d;
                System.out.println("Marks must be between 0 and 100.");
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number.");
            }
        }
    }

    private static void saveToFile() {
        try (PrintWriter pw = new PrintWriter(new FileWriter(FILE_NAME))) {
            for (Student s : students) pw.println(s.toFileString());
        } catch (IOException e) {
            System.out.println("Error saving data: " + e.getMessage());
        }
    }

    private static void loadFromFile() {
        File f = new File(FILE_NAME);
        if (!f.exists()) return;
        try (BufferedReader br = new BufferedReader(new FileReader(f))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] p = line.split(",");
                if (p.length == 4)
                    students.add(new Student(Integer.parseInt(p[0]), p[1], p[2], Double.parseDouble(p[3])));
            }
        } catch (IOException | NumberFormatException e) {
            System.out.println("Error loading data: " + e.getMessage());
        }
    }
}
