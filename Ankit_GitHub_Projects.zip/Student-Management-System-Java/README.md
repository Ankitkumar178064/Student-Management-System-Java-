# Student Management System (Java)

A console-based application to manage student records using Object-Oriented Programming and file handling.

## Features
- Add, view, search, update and delete student records
- Automatic grade calculation (A+, A, B, C, F)
- Input validation (duplicate IDs, marks range, invalid numbers)
- Data saved permanently in `students.txt`

## Concepts Used
Classes and objects, encapsulation, ArrayList, file I/O (`BufferedReader`, `PrintWriter`), exception handling, menu-driven programming.

## How to Run
```bash
javac StudentManagementSystem.java
java StudentManagementSystem
```

## Sample Output
```
===== STUDENT MANAGEMENT SYSTEM =====
1. Add Student
2. View All Students
...
ID     Name                 Course       Marks    Grade
101    Rahul Kumar          BCA          82.50    A
```

## Author
Ankit Kumar Rajak
