# Sales Data Analysis (Advanced Excel)

Analysis of 60 sample sales orders (Jan–Jun 2025) using formulas, pivot tables and charts.

## Files
- `sales_data.csv` – raw dataset (OrderID, Date, Region, Product, Quantity, UnitPrice)

## Step-by-Step Guide
1. Open `sales_data.csv` in Excel and save as `Sales_Analysis.xlsx`.
2. **Add Total Sales column** – in G1 type `TotalSales`, in G2 enter `=E2*F2` and fill down.
3. **Add Month column** – in H1 type `Month`, in H2 enter `=TEXT(B2,"mmm")` and fill down.
4. **Format as Table** – select data, press `Ctrl+T`.
5. **Summary formulas** (new sheet "Summary"):
   - Total revenue: `=SUM(Sales[TotalSales])`
   - Total orders: `=COUNTA(Sales[OrderID])`
   - Average order value: `=AVERAGE(Sales[TotalSales])`
   - Revenue for one region: `=SUMIF(Sales[Region],"East",Sales[TotalSales])`
   - Best product lookup: `=INDEX(A:A, MATCH(MAX(B:B), B:B, 0))` on the product-wise pivot
6. **Pivot Tables** (Insert → PivotTable):
   - Rows: `Product`, Values: Sum of `TotalSales` (top-selling products)
   - Rows: `Month`, Values: Sum of `TotalSales` (monthly trend)
   - Rows: `Region`, Values: Sum of `TotalSales` (regional performance)
7. **Charts** – Column chart for products, line chart for monthly sales, pie chart for regions.
8. **Dashboard** – place the three charts and the key numbers (total revenue, orders, average) on one sheet named "Dashboard". Add Slicers for Region and Product.
9. **Insights** – write 3 lines on the Dashboard: best product, best month, best region.

## Skills Demonstrated
Data cleaning, formulas (SUM, SUMIF, AVERAGE, INDEX/MATCH, TEXT), Pivot Tables, charts, slicers, dashboard design.

## Author
Ankit Kumar Rajak
