# Ankit Kumar Rajak – Projects

B.C.A. student at Jharkhand Rai University, Ranchi. Interested in software development and data analytics.

| Project | Tech | Description |
|---|---|---|
| [Student Management System](Student-Management-System-Java) | Java | Console app with OOP, file handling and CRUD operations |
| [Library Management System](Library-Management-System-CPP) | C++ | Menu-driven book issue/return system with file storage |
| [Employee Database](Employee-Database-SQL) | SQL | Two-table database with 10 queries including JOINs and GROUP BY |
| [Sales Data Analysis](Sales-Data-Analysis-Excel) | Advanced Excel | Pivot tables, formulas and dashboard on sales data |

## Contact
Email: helloankit071@gmail.com
