# Library Management System (C++)

A menu-driven C++ program to manage a small library.

## Features
- Add, display, search and delete books
- Issue and return books with status tracking
- Data stored permanently in `books.txt` (file handling)
- Input validation

## Concepts Used
Classes and objects, `vector`, file streams (`ifstream`, `ofstream`), string handling, functions, loops and switch.

## How to Run
```bash
g++ library.cpp -o library
./library        # Windows: library.exe
```

## Author
Ankit Kumar Rajak
