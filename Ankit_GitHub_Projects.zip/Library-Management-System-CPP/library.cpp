// Library Management System
// Menu-driven C++ program using classes, vectors and file handling.
// Features: add book, display books, search, issue, return, delete.

#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <limits>
using namespace std;

class Book {
public:
    int id;
    string title;
    string author;
    bool issued;

    Book() : id(0), issued(false) {}
    Book(int i, string t, string a, bool is = false)
        : id(i), title(t), author(a), issued(is) {}
};

const string FILE_NAME = "books.txt";
vector<Book> books;

void saveBooks() {
    ofstream out(FILE_NAME);
    for (const Book &b : books)
        out << b.id << "|" << b.title << "|" << b.author << "|" << b.issued << "\n";
}

void loadBooks() {
    ifstream in(FILE_NAME);
    string line;
    while (getline(in, line)) {
        stringstream ss(line);
        string id, title, author, issued;
        getline(ss, id, '|');
        getline(ss, title, '|');
        getline(ss, author, '|');
        getline(ss, issued, '|');
        if (!id.empty())
            books.push_back(Book(stoi(id), title, author, issued == "1"));
    }
}

int findBook(int id) {
    for (size_t i = 0; i < books.size(); i++)
        if (books[i].id == id) return (int)i;
    return -1;
}

int readInt(const string &prompt) {
    int x;
    while (true) {
        cout << prompt;
        if (cin >> x) {
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            return x;
        }
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        cout << "Please enter a valid number.\n";
    }
}

void addBook() {
    int id = readInt("Enter book ID: ");
    if (findBook(id) != -1) {
        cout << "A book with this ID already exists.\n";
        return;
    }
    string title, author;
    cout << "Enter title: ";
    getline(cin, title);
    cout << "Enter author: ";
    getline(cin, author);
    books.push_back(Book(id, title, author));
    saveBooks();
    cout << "Book added successfully.\n";
}

void displayBooks() {
    if (books.empty()) {
        cout << "No books in the library.\n";
        return;
    }
    cout << "\nID\tTitle\t\t\tAuthor\t\tStatus\n";
    cout << "------------------------------------------------------------\n";
    for (const Book &b : books)
        cout << b.id << "\t" << b.title << "\t\t" << b.author << "\t\t"
             << (b.issued ? "Issued" : "Available") << "\n";
}

void searchBook() {
    cout << "Enter title keyword: ";
    string key;
    getline(cin, key);
    bool found = false;
    for (const Book &b : books) {
        if (b.title.find(key) != string::npos) {
            cout << b.id << " - " << b.title << " by " << b.author
                 << " [" << (b.issued ? "Issued" : "Available") << "]\n";
            found = true;
        }
    }
    if (!found) cout << "No matching books found.\n";
}

void issueBook() {
    int idx = findBook(readInt("Enter book ID to issue: "));
    if (idx == -1) cout << "Book not found.\n";
    else if (books[idx].issued) cout << "Book is already issued.\n";
    else {
        books[idx].issued = true;
        saveBooks();
        cout << "Book issued successfully.\n";
    }
}

void returnBook() {
    int idx = findBook(readInt("Enter book ID to return: "));
    if (idx == -1) cout << "Book not found.\n";
    else if (!books[idx].issued) cout << "This book was not issued.\n";
    else {
        books[idx].issued = false;
        saveBooks();
        cout << "Book returned successfully.\n";
    }
}

void deleteBook() {
    int idx = findBook(readInt("Enter book ID to delete: "));
    if (idx == -1) cout << "Book not found.\n";
    else {
        books.erase(books.begin() + idx);
        saveBooks();
        cout << "Book deleted successfully.\n";
    }
}

int main() {
    loadBooks();
    int choice;
    do {
        cout << "\n===== LIBRARY MANAGEMENT SYSTEM =====\n"
             << "1. Add Book\n2. Display Books\n3. Search Book\n"
             << "4. Issue Book\n5. Return Book\n6. Delete Book\n7. Exit\n";
        choice = readInt("Enter your choice: ");
        switch (choice) {
            case 1: addBook(); break;
            case 2: displayBooks(); break;
            case 3: searchBook(); break;
            case 4: issueBook(); break;
            case 5: returnBook(); break;
            case 6: deleteBook(); break;
            case 7: saveBooks(); cout << "Goodbye!\n"; break;
            default: cout << "Invalid choice.\n";
        }
    } while (choice != 7);
    return 0;
}
